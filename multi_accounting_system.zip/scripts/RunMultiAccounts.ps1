# اجرای سیستم مولتی‌اکانتینگ
Set-ExecutionPolicy Bypass -Scope Process -Force

Write-Host "راه‌اندازی حساب‌های مجزا..."
# اینجا اسکریپت‌های کانتینری و تنظیمات اجرا خواهند شد

Write-Host "سیستم مولتی‌اکانتینگ در حال اجرا است."
