# اسکریپت نصب پیش‌نیازها
Set-ExecutionPolicy Bypass -Scope Process -Force

# فعال‌سازی WSL، Virtual Machine Platform، و Hyper-V
dism.exe /online /enable-feature /featurename:Microsoft-Windows-Subsystem-Linux /all /norestart
dism.exe /online /enable-feature /featurename:VirtualMachinePlatform /all /norestart
dism.exe /online /enable-feature /featurename:Microsoft-Hyper-V-All /all /norestart

# ریست و نصب مجدد WSL2
wsl --shutdown
wsl --unregister Ubuntu
wsl --install -d Ubuntu
wsl --set-default-version 2

# دانلود و نصب Docker Desktop
$docker_installer = "https://desktop.docker.com/win/main/amd64/Docker%20Desktop%20Installer.exe"
Invoke-WebRequest -Uri $docker_installer -OutFile "dependencies/DockerInstaller.exe"
Start-Process "dependencies/DockerInstaller.exe" -ArgumentList "install --quiet --accept-license" -Wait

# نصب مجدد Minikube
$minikube_url = "https://github.com/kubernetes/minikube/releases/latest/download/minikube-windows-amd64.exe"
Invoke-WebRequest -Uri $minikube_url -OutFile "dependencies/minikube.exe"
Move-Item "dependencies/minikube.exe" "C:\minikube\minikube.exe" -Force

# دانلود مرورگر Anti-Detect
$multilogin_browser = "https://download.multilogin.com/mlbrowser-latest.exe"
Invoke-WebRequest -Uri $multilogin_browser -OutFile "dependencies/mlbrowser.exe"
Start-Process "dependencies/mlbrowser.exe" -Wait

# دانلود و نصب VPN و پروکسی (ProtonVPN)
$vpn_installer = "https://protonvpn.com/download/ProtonVPN_setup.exe"
Invoke-WebRequest -Uri $vpn_installer -OutFile "dependencies/ProtonVPN_setup.exe"
Start-Process "dependencies/ProtonVPN_setup.exe" -Wait

Write-Host "✅ پیش‌نیازها نصب شدند. لطفاً سیستم را ری‌استارت کنید."
