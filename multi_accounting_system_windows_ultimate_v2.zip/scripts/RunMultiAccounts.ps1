# اجرای سیستم مولتی‌اکانتینگ
Set-ExecutionPolicy Bypass -Scope Process -Force

# بررسی وضعیت WSL و Docker
wsl --list --verbose
Start-Process "C:\Program Files\Docker\Docker\Docker Desktop.exe"
Start-Sleep -Seconds 15

# بررسی و راه‌اندازی Minikube
minikube delete
minikube start --driver=docker

# اجرای مرورگر Anti-Detect برای مولتی‌اکانتینگ
Start-Process "C:\Program Files\Multilogin\mlbrowser.exe"

# اجرای VPN برای هر اکانت مجزا
Start-Process "C:\Program Files\ProtonVPN\ProtonVPN.exe"

Write-Host "✅ سیستم مولتی‌اکانتینگ در حال اجرا است."
