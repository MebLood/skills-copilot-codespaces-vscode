#!/usr/bin/env python3
import time, psutil

print("Monitoring: collecting system metrics...")

metrics = {
    "cpu_percent": psutil.cpu_percent(interval=1),
    "memory_percent": psutil.virtual_memory().percent,
    "disk_percent": psutil.disk_usage('/').percent,
    "timestamp": time.time()
}

print(f"Metrics: {metrics}")
