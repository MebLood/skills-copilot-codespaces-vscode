#!/usr/bin/env python3
import os, subprocess, time, sys

print("=== Starting self_executing_manager.py ===")

required_files = ["setup_and_run.sh", "monitoring.py", "self_healing.py"]

for filename in required_files:
    if not os.path.exists(filename):
        with open(filename, "w") as f:
            f.write(f"# Placeholder for {filename}
")
        print(f"{filename} not found. Created placeholder.")

def run_command(command):
    try:
        result = subprocess.run(command, shell=True, check=True, capture_output=True, text=True)
        print(result.stdout)
    except subprocess.CalledProcessError as e:
        print(f"Command failed: {command}
Error: {e.stderr}")

while True:
    run_command("python3 monitoring.py")
    run_command("python3 self_healing.py")
    time.sleep(30)
