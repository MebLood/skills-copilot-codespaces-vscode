#!/bin/bash
set -e

LOGFILE="setup_and_run_$(date +%Y%m%d%H%M%S).log"
exec > >(tee -a "$LOGFILE") 2>&1

echo "=== Starting setup_and_run.sh at $(date) ==="

check_internet() {
  local testhost="8.8.8.8"
  if ping -c 1 -W 5 $testhost > /dev/null 2>&1; then
    return 0
  else
    return 1
  fi
}

MAX_RETRIES=5
retry=0
until check_internet; do
  retry=$((retry+1))
  if [ $retry -ge $MAX_RETRIES ]; then
    echo "Internet connection not available. Please check your connection."
    exit 1
  fi
  echo "No internet connection. Retrying in 10 seconds... ($retry/$MAX_RETRIES)"
  sleep 10
done
echo "Internet connection is active."

echo "Checking and installing required dependencies..."

install_if_missing() {
  local cmd="$1"
  local install_cmd="$2"
  local name="$3"
  
  if ! command -v $cmd >/dev/null 2>&1; then
    echo "$name not found. Installing..."
    eval "$install_cmd"
  else
    echo "$name is installed: $($cmd --version)"
  fi
}

install_if_missing "python3" "sudo apt install -y python3" "Python"
install_if_missing "pip3" "python3 -m ensurepip" "Pip"
install_if_missing "git" "sudo apt install -y git" "Git"
install_if_missing "kubectl" "sudo apt install -y kubectl" "Kubernetes CLI"
install_if_missing "minikube" "curl -Lo minikube https://storage.googleapis.com/minikube/releases/latest/minikube-linux-amd64 && chmod +x minikube && sudo mv minikube /usr/local/bin/" "Minikube"
install_if_missing "docker" "sudo apt install -y docker.io" "Docker"

pip install -U pip setuptools wheel psutil requests kafka-python prometheus-client

echo "Launching self-executing manager..."
python3 self_executing_manager.py
