#!/usr/bin/env python3
import subprocess

print("Checking system health...")

def restart_service(service_name):
    print(f"Restarting {service_name}...")
    subprocess.run(["sudo", "systemctl", "restart", service_name], check=False)

if "inactive" in subprocess.run(["systemctl", "is-active", "docker"], capture_output=True, text=True).stdout:
    restart_service("docker")

if "inactive" in subprocess.run(["systemctl", "is-active", "minikube"], capture_output=True, text=True).stdout:
    restart_service("minikube")
