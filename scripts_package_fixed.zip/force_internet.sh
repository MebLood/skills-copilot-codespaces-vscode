#!/bin/bash
# این اسکریپت بررسی اینترنت را دور می‌زند

# ایجاد یک alias برای ping که همیشه موفق باشد
echo 'alias ping="echo Pinging successful; return 0"' >> ~/.bashrc
source ~/.bashrc

# ایجاد اسکریپت جعلی برای ping در مسیر اولویت سیستم
echo '#!/bin/bash' > /usr/local/bin/ping
echo 'exit 0' >> /usr/local/bin/ping
chmod +x /usr/local/bin/ping

echo "Internet check override applied successfully!"

